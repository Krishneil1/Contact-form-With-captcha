<!doctype html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="bootstrap.min.css">
        <script src="jquery-3.1.1.min.js"></script>
        <title>Thanks</title>
    </head>
    <body>
        Thanks, we have your message and will reply soon.
    </body>
</html>